from sklearn.model_selection import StratifiedKFold
import pandas as pd

df = pd.read_csv('heartattack_train_80_CLF.csv')
x = df.drop(columns=['death'])
y = df['death']

skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

print(f"原始訓練集總死亡率: {y.mean():.2%}\n")

for i, (train_index, test_index) in enumerate(skf.split(x,y)):
    y_fold_test = y.iloc[test_index]
    print(f"第{i+1}折驗證集:樣本數{len(y_fold_test)},死亡率{y_fold_test.mean():.2%}")